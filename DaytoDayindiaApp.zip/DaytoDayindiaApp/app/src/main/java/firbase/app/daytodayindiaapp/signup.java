package firbase.app.daytodayindiaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class signup extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
    }
    public void googles(View view)
    {
        Intent i= new Intent(signup.this,WelcomeActivity.class);
        startActivity(i);
    }
}
